var app = require("express")();
var http = require("http").Server(app);
var io = require("socket.io")(http);
var fs = require("fs");

app.get("/", function(req, res){
	function callback(data){

		//发送数据
		res.send(data.toString());
	}

	fs.readFile("./socketToClient.html", function(err, data){
		if(err){
			console.log(err);
			callback("文件不存在");
		}else{
			//将数据传出去
			callback(data);
		}
	})
})